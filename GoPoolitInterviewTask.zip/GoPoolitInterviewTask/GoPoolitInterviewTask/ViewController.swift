//
//  ViewController.swift
//  GoPoolitInterviewTask
//
//  Created by admin on 16/09/20.
//  Copyright © 2020 admin. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    // declare
    let appDelegate = UIApplication.shared.delegate as! AppDelegate //Singlton instance
    var context:NSManagedObjectContext!
  
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.getDataFromAPI()
  }
    //api calling for getting data from Server
     func getDataFromAPI()  {
         
    // Set up the URL request
     let urlString: String = "http://newsapi.org/v2/everything?q=bitcoin&from=2020-08-16&sortBy=publishedAt&apiKey=ac81826617404f9896e3419cc1428d42"
           
        guard let url = URL(string: urlString) else {
              print("Error: cannot create URL")
              return
            }
            let urlRequest = URLRequest(url: url)

            // set up the session
            let config = URLSessionConfiguration.default
            let session = URLSession(configuration: config)

            // make the request
            let task = session.dataTask(with: urlRequest) {
              (data, response, error) in
              // check for any errors
              guard error == nil else {
                print("error calling GET on /todos/1")
                print(error!)
                return
              }
              // make sure we got data
              guard let responseData = data else {
                print("Error: did not receive data")
                return
              }
              // parse the result as JSON, since that's what the API provides
              do {
                guard let jsonResponse = try JSONSerialization.jsonObject(with: responseData, options: [])
                  as? [String: Any] else {
                    print("error trying to convert data to JSON")
                    return
                }
                // now we have the todo
                // let's just print it to prove we can access it
               // print("The todo is: " + jsonResponse.description)
                
                let array = jsonResponse["articles"] as! Array<Any>
                print(array as Any)
                
            for item in array{
                 
                var title: String? = nil
                var description: String? = nil
                var urlToImage: String? = nil
                
          if let titleName = (item as AnyObject).value(forKey: "title") as? String{
                    title = titleName
              }
          if let descriptionName = (item as AnyObject) .value(forKey: "description") as? String{
                    description = descriptionName
                }
          if let imageURL = (item as AnyObject) .value(forKey: "urlToImage") as? String {
                print(imageURL)
                urlToImage = imageURL
            }
          //save to coredata
               self.context = self.appDelegate.persistentContainer.viewContext
                let entity = NSEntityDescription.entity(forEntityName: "News", in: self.context)
                let newUser = NSManagedObject(entity: entity!, insertInto: self.context)
                newUser.setValue(title, forKey: "title")
                newUser.setValue(description, forKey: "ndescription")
                newUser.setValue(urlToImage, forKey: "imageURL")

                print("Storing Data..")
                       do {
                        try self.context.save()

                      } catch {
                           print("Storing data Failed")
                      }
              }
                
              } catch  {
                print("error trying to convert data to JSON")
                return
              }
            }
            task.resume()
           
    }

    @IBAction func showList(_ sender: Any) {
        if #available(iOS 13.0, *) {
            let listVC = self.storyboard?.instantiateViewController(identifier: "listVC") as! ListViewController
            self.navigationController?.pushViewController(listVC, animated: true)
        } else {
            
        }
  }
    
}

