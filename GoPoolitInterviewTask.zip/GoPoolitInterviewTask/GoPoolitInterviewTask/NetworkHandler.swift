//
//  NetworkHandler.swift
//  GoPoolitInterviewTask
//
//  Created by admin on 16/09/20.
//  Copyright © 2020 admin. All rights reserved.
//

import UIKit
import Reachability

class NetworkHandler: NSObject {
    
    static  let shared = NetworkHandler()

    var reachabilityStatus: Reachability.Connection = .unavailable
    let reachability = try! Reachability()

    var isNetworkAvailable : Bool {
        return reachabilityStatus != .unavailable
    }
    
    func startListner() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(reachabilityChanged(note:)), name: .reachabilityChanged, object: reachability)
    
        
        reachability.whenReachable = { reachability in
            if reachability.connection == .wifi {
                print("Reachable via WiFi")
            } else {
                print("Reachable via Cellular")
            }
        }
        reachability.whenUnreachable = { _ in
            print("Not reachable")
            
            let alert = UIAlertController(title: "Alert", message: "Not reachable", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
        }
        
        do {
            try reachability.startNotifier()
        } catch {
            print("Unable to start notifier")
        }
    }
    
    @objc func reachabilityChanged(note: Notification) {
       
       let reachability = note.object as! Reachability
       
       switch reachability.connection {
       case .wifi:
           print("Reachable via WiFi")
       case .cellular:
           print("Reachable via Cellular")
       case .unavailable:
           print("Network not reachable")
       case .none:
           print("Network none")
       }
    }
}
