//
//  ListViewController.swift
//  GoPoolitInterviewTask
//
//  Created by admin on 16/09/20.
//  Copyright © 2020 admin. All rights reserved.
//

import UIKit
import CoreData
import SDWebImage
import MBProgressHUD

class ListViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

        // declare
       let appDelegate = UIApplication.shared.delegate as! AppDelegate //Singlton instance
       var context:NSManagedObjectContext!
      let fetchedArray = NSMutableArray()
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

       self.fetchData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fetchedArray.count
      }
      
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
              
        cell.lblTitle.text = ((fetchedArray[indexPath.row] as AnyObject).value(forKey:
                     "title")) as? String
               
        cell.lblDesc.text = (((fetchedArray[indexPath.row] as AnyObject).value(forKey:
                      "description")) as! String)
                 
        if  let urlString =  (((fetchedArray[indexPath.row] as AnyObject).value(forKey:
                "imageURL")) as? String) {
        SDWebImageManager.shared().loadImage( with: URL(string: urlString), options: .highPriority, progress: nil) { (image, data, error, cacheType, isFinished, imageUrl) in
                print(isFinished)
                cell.img.image = image
            }
        }
        return cell
      }
    //fetching title,description and imageUrl from coredata
    func fetchData()
    {
        print("Fetching Data..")
        MBProgressHUD.showAdded(to: self.view, animated: true)
      self.context = self.appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "News")
        request.returnsObjectsAsFaults = false
        do {
            MBProgressHUD.hide(for: self.view, animated: true)
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject] {
                let title = data.value(forKey: "title") as! String
                let description = data.value(forKey: "ndescription") as! String
             var urlToImage: String? = nil
             if let imageURL = data.value(forKey: "imageURL") as? String {
                 urlToImage = imageURL
                 
             }
            
             var tempDict: [String:String] = [:]
                                  
             tempDict["title"] = title
             tempDict["description"] = description
             tempDict["imageURL"] = urlToImage
             
             fetchedArray.add(tempDict)
             
             print(fetchedArray)
             self.tableView.reloadData()
            }
        } catch {
            print("Fetching data Failed")
        }
    }
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
